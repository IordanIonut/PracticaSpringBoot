create
    definer = root@localhost procedure InsertAccount(IN namep varchar(250), IN Emailp varchar(250),
                                                     IN pa1p varchar(250), IN pa2p varchar(250))
BEGIN
	insert into carslist.new_table(name,Email,password1,pasword2) 
		values (namep,Emailp,pa1p,pa2p);
END;

